# Training Logs

`main-log.md` contains detailed information about each restart of training during GLM-130B training.

Tensorboard logs is available at [here](https://cloud.tsinghua.edu.cn/f/503ef9fa85b84fbba9ef/).
